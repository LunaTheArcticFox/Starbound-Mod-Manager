--witless tweak and QOL pack v. TIB++--
---------------------------------------
built for Starbound version Angry Koala

-various personal mods that i have decided to release to the public much to no expected fanfare at all
-override instructions thanks to rick


--update log--
--------------
version "this is bullshit++"
-everything: drop in method should work now, thanks to rick.

version "this is bullshit"
-guntweakmod: speed values shifted.
-meleetweakmod: DPS ranges changed to be in line with crafted weapons, top speeds made slower
-minefaster: even faster mining. work that pick bitch
-refinerator: New!

version "fuck the earth"
-footweakmod: speed values adjusted for weapon rarity. more common weapons have a higher minimum attack speed (weaker knockback)
-guntweakmod: added a default_movement.config with a fixed value for speedlimit to make fast projectiles work better.
-meleetweakmod: wider DPS ranges for uncommon and higher weapons.
-weapondropmod_foo: tweaked drop rates; npcs in particular will no longer drop everything they have sometimes.



charcoal - Adds charcoal to the game, various materials can be fed to the furnace to produce charcoal.
fuelsupply - Uranium fuel and above increased in value, to facilitate easier interstellar travel.
weapondropmod - fixes and readjusts weapon drop rates (guns in particular have too many trailing 0s in the drop rate and common guns were somehow rarer than uncommon ones)
    (don't run with weapondropmod_startwithgun)
weapondropmod_startwithgun - weapondropmod, only you start with a gun on a new character 
    (don't run with base weapondropmod)
guntweakmod - readjusts and rebalances randomly generated firearms to actually work with starbound's haphazard loot system
meleetweakmod - readjusts and rebalances randomly generated melee weapons to actually work with starbound's haphazard loot system
minefaster - increases speed and power of mining tools across the board
refinerator - adds later unrefineable metals to be refineable! hoo-fucking-rah

Drop-in:
1. copy mods you want over to Starbound/mods/ and hope things don't explode when you launch them

Manual install:
1. copy /assets/ directories of the mods you want over Starbound/assets/ and replace everything when prompted
2. run game



========
charcoal
========

wood planks, plant fiber, and other carbon-rich produce will burn in furnaces into charcoal.
things such as rainbow wood and the buggy 2nd type of wood can also be turned into coal.

ratios (material:charcoal)
-------------------------
tar		10:3
wood planks	9:2
plant fiber	6:1
giant petals	20:3

rice		1:2
corn		1:2
potatoes	1:2
sugar		1:3


charcoal can be used in torches at the same efficiency as regular coal.

charcoal is 1 ship fuel per unit of charcoal.




====================================
weapondropmod & weapondropmod_startwithgun
====================================

fixes and readjusts weapon drop rates (guns in particular have too many trailing 0s in the drop rate and common guns were somehow rarer than uncommon ones)

also adjusts "tier2" weapon drops to work better with meleetweakmod

also, "guard" npcs (there are a lot of these!) and apex war criminals now have a chance to drop firearms

they're still not common, but at least they're not at the level of "fucking insignificant"

_startwithgun starts new characters with a gun.

!!!!!!!WARNING!!!!!!! - do not install both. choose one.




===========
guntweakmod
===========

-DPS adjusted for each weapontype and rarity tier (see witlessmodpack_technicalmanual.txt for chart)
-readjusts and rebalances firearms to actually work with starbound's haphazard loot system
-currently using the counterintuitive "multiplier" to balance weapon types. When this is changed, the mod will be rebuilt again.

marked changes:
-DPS efficiency adjusted for each weapontype and rarity tier (see a little ways below for chart) with plasma weapons being an additional +1 rarity modifer for multiplier.
-rate of fire changed for certain types of weapons:
 -assault rifles have a fire rate range of [ 3, 12 ],  up from 3-8
   -plasma assault rifles have a fire rate range of [ 3, 8.57 ]
 -grenade launchers have a fire rate range of [ 0.5, 2.0 ], up from 0.3-1.0
 -machine pistols have a fire rate range of [ 8.57, 15 ],  up from 2-7 (2 shots per second??!?!)
   -plasma machine pistols have a fire rate range of [ 6.0, 8.57 ]
 -pistols have a fire rate range of [ 0.66, 4 ], up from 0.5-4
 -rocket launchers have a fire rate range of [ 0.5, 2.5 ], up from 0.3-1.0
 -shotguns have a fire rate range of [ 0.5, 4.0 ], up from 0.5-4
   -plasma shotguns have a fire rate range of [ 0.5, 2.0 ]
 -plasma sniper rifles have a fire rate range of [ 0.5, 1.0 ]



=============
meleetweakmod
=============

-readjusts and rebalances randomly generated melee weapons to actually work with starbound's haphazard loot system
-currently using the counterintuitive "multiplier" to balance weapon types. When this is changed, the mod will be rebuilt again.

marked changes:
-DPS adjusted for each weapontype and rarity tier (see witlessmodpack_technicalmanual.txt for chart)
-Legendary weapon stats now randomized.
-"tier2" weapons now changed to rare and legendary random weapons, respectively. Buggy level modifier also removed.