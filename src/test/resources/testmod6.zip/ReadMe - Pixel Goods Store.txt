Pixel Goods Store: Furniture, furnishings and equipment!
===============================
Version 1.10 - Enraged Koala" compatible. ('unstable' version compatibility is NOT guaranteed).

1. Description:
----------------
This mod simply adds a new station "Pixel Goods Store" (formerly known as OKEA Kiosk), which allows you to purchase all kinds of custom decorative and furniture objects for your home, base or starship. 
As of version 1.10 mod includes 315 custom items, of which 187 support Dye mod for 9 different colors.

V1.10 also includes catalog of 28 exotic xeno plants in pots from Frackin' Flora mod by Sayter - http://community.playstarbound.com/index.php?resources/frackin-flora.925/ and a Hops plant from Starbooze mod by Kingofcrows - http://community.playstarbound.com/index.php?resources/starbooze%E2%84%A2-winepress-update.1083/

Exclusive Items:
By progressing further in game you unlock new, unique items.
As of V1.10 first four tiers of starmap upgrades unlock new items.


2. Installation: 
----------------
This mod is delivered in single file format and it doesn't require it's own folder, just drop pgs.modpak in your /mods folder.

If you're installing unpacked version, then extract archive to /Starbound/mods, path to pgs.modinfo should be -  /starbound/mods/pgs/pgs.modinfo

WARNING!!!
Mod works in multiplayer only if server and all of the players have it installed (same version), otherwise you might lose some of the items.

If you're getting 'dyeengine' related error, then installing dye mod will help you to get rid of it.

3. Modders info:
----------------
Unique material IDs reserved: 7300-7325

If you'd like to release your own items pack for this mod, contact me and i'll feature it on mod page or include it in the next version with credits if you'd want me to.
----------------

Version 1.10 changes:
- Added 23 new items, including a "Hi-tech" item set.
- Mod is now delivered in single file form and doesn't require it's own folder, just extract it in your /mods folder.

Version 1.09 changes:
- Added 22 new items, all from a "Living Stone" item set.
- some art changes to a few existing decorative objects.
- To avoid bad press after a huge fiasco that happened in beta sector after an apex workforce rebellion over banana-shaped meatballs - board of directors decided to rebrand the company and now okea items are sold under a new name - "Pixel Goods Store!". The prices still remain low, manufacturing now is even more cheaper, with floran workforce that only requires watering once a week and some apex meat.

Version 1.08 changes:
- To appease its customers demands for more liberal prices OKEA Corporation board of directors made a bold move to outsource most menial labour tasks to Apex labour camps in sector B. And in result - prices on all items in stock dropped by approximately 50%. Now you can purchase twice as many products with the same amount of pixels, Because we care!
- Added 24 new items, including Human-themed ones.
- Wooden logs for florans to build sturdier houses and more decorative xeno plants, courtesy of Sayter - author of Frackin Flora.

Version 1.07 changes:
- Added 16 new items, including Floran-themed ones.
- Virtual Windows!

Version 1.06 changes:
- Added 30 new items, including Avian and Hylotl themed ones.
- Again fixed some items from appearing in 3D printer menu after they've been purchased.

Version 1.05 changes:
- After thorough testing block and platform objects are now re-enabled. The only way you could corrupt your character using those is by misuse of mod and/or game files. It is strongly recommended not to uninstall mod once you've purchased any of those.
- Added 25 new items, including a dozen of Apex-themed ones.
- Jellyblocks were re-enabled, to access those you need to craft and use durasteel starmap upgrade.
- Now Okea Kiosk station can be turned both left and right when placed.

Reminders:
If you already have killed game bosses, but don't have access to boss-themed items, then you need to craft and use starmap upgrades that require boss drops.
Do not uninstall this mod if you've purchased any block or platform items, unless you get rid of all of them (including placed ones), your character might become unplayable.
Dyeing Bucket mod, it's recommended for a better variety, 114 okea items support it for 9 different colors.


Version 1.04 changes:
- Added 17 new items, including Giant Jelly boss themed ones.
- Added compact version of Kiosk for players with limited interior space.
- Catalogs are disabled till all the compatibility issues with other mods can be resolved, boss items are unlockable by tier progression now.
- Block and platform items are also disabled, there is a very nasty bug around that causes some players with a week+ old universe to crash upon purchasing any custom  block object and renders their character completely unplayable. Blocks are only disabled, not removed, so if you still have them, or unlocked them before - you can keep on using them, but at your own risk. Hopefully it gets fixed with next patch.
- Mod is now delivered in .pak form to increase performanse and game loading time, if only by a little, also in the future it'll be required for multiplayer compatibility.
- Racial buttons added to the interface.
- First batch of glitch-themed items are in stock, expect more themed items with future updates!

Version 1.03 changes:
- Fixed curtains and blinds, now they'll keep their color after they've been moved.
- Most of the lights can now have their lightbulb color changed with dyeing bucket.
- Added 20 more items to the kiosk (be careful with air coolers, they can actually freeze you to death!).
- Added Bone Dragon catalog (Slay the dragon!).
- Rebalanced prices on some items. 

Version 1.02 changes:
- Removed 4 window blinds and 2 curtains.
- Added 8 different size curtains and 10 different size window blinds that work with dyeing bucket mod.
- Added garden lighs collection and few other items.

Version 1.01 changes:
- Fixed some items from appearing in 3D printer menu after they've been purchased.
- Adjusted few prices.

---------------
Feedback, suggestions and constructive criticism are appreciated!

Author: Boogy aka Anipsy